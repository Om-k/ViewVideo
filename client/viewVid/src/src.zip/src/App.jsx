import { useState } from 'react'
import FrontPage from './Components/FrontPageData/FrontPage'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <FrontPage/>
    </>
  )
}

export default App
