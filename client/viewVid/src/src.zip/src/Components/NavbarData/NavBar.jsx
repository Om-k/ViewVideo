import React from "react";
import "./NavBar.css"

const NavBar = () => {
    return (
        <>
        <div className="NavBar">
        </div>
         <div className="NavBarPos"></div>
        </>
    );
};

export default NavBar