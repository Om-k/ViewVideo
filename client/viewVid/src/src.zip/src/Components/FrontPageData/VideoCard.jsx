import React from "react";
import "./VideoCard.css"
import MyThumbnail from './../../assets/MyThumbnail.png'

const views = "1k"
const uploaded = "1 month"

const VideoCard = () => {
    return (
        <div className="videoCardBack">
            <img src={MyThumbnail} className="videoThumbnail"></img>
                <div className="MainTitleArea">
                <img src={MyThumbnail} className="videoCardChannelImg"></img>
                    <div className="channelData">
                    <h4 className="VideoTitle">Video Title</h4>
                    <p className="channelDataTxt gapTop">Channel Name</p>
                    <div className="vidContentText">
                        <p className="channelDataTxt">{views + " "}views</p>
                        <p className="channelDataTxt textGap">.</p>
                        <p className="channelDataTxt textGap">{uploaded + " "}ago</p>
                    </div>
                    </div>
                </div>
        </div>
    );
};

export default VideoCard