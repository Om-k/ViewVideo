import React from "react";
import "./VideosArea.css";
import VideoCard from "./VideoCard";

const videos = [{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}];
const SideBarExpand = false
const isPc = true

const VideosArea = () => {
    return (
        <div>
            <div className="grid-container" style={SideBarExpand && isPc ? {display:'grid',gridTemplateColumns: '33.33% 33.33% 33.33%'} : {}}>
                {videos.map((video) => (
                    <div className="grid-item"><VideoCard /></div>
                ))}
            </div>
        </div>
    );
};

export default VideosArea;
