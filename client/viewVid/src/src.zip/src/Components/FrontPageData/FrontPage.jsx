import React from "react";
import "./FrontPage.css"
import VideosArea from "./VideosArea";
import NavBar from "../NavbarData/NavBar";
import SideBar from "../SideBarData/SideBar"

const SideBarExpand = false

const FrontPage = () => {
    return (
        <div>
            {/* <VideoCard /> */}
            <NavBar/>
            <div className="videoAndSideBarCont">
                <SideBar/>
                <div className="VideosAreaCont" style={SideBarExpand ? {width:'80%'} : {width:'94%'}}>
                <VideosArea/>
                </div>
            </div>
        </div>
    );
};

export default FrontPage