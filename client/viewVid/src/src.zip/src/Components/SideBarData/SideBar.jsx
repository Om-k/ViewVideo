import React from "react";
import "./SideBar.css"

const SideBarExpand = false

const SideBar = () => {
    return (
        <>
         <div className="sideBar" style={SideBarExpand ? {width:'20%'} : {width:'6%'}}></div>
         <div className="sideBarPos" style={SideBarExpand ? {width:'20%'} : {width:'6%'}}></div>
        </>
    );
};

export default SideBar